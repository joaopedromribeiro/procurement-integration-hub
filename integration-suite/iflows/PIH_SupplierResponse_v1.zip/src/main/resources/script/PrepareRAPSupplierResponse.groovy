import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

Message processData(Message message) {

    def body = message.getBody(String)
    def input = new JsonSlurper().parseText(body)

    def requiredFields = [
        'schemaVersion',
        'responseId',
        'sourceSystem',
        'sourceOrderId',
        'sourceRevision',
        'deliveryId',
        'supplierCode',
        'responseVersion',
        'decision',
        'respondedAt'
    ]

    requiredFields.each { field ->
        if (input[field] == null || input[field].toString().trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Missing mandatory supplier response field: ${field}"
            )
        }
    }

    if (!(input.decision in ['ACCEPTED', 'REJECTED'])) {
        throw new IllegalArgumentException(
            "Unsupported supplier response decision: ${input.decision}"
        )
    }

    if (input.decision == 'REJECTED' &&
        (input.reason == null || input.reason.toString().trim().isEmpty())) {
        throw new IllegalArgumentException(
            "Reason is mandatory when decision is REJECTED"
        )
    }

    def normalizeGuid = { value ->
        if (value == null || value.toString().trim().isEmpty()) {
            return null
        }

        def raw = value.toString()
                       .replace('-', '')
                       .trim()
                       .toLowerCase()

        if (!(raw ==~ /[0-9a-f]{32}/)) {
            throw new IllegalArgumentException(
                "Invalid UUID value: ${value}"
            )
        }

        return raw.substring(0, 8)  + '-' +
               raw.substring(8, 12) + '-' +
               raw.substring(12, 16) + '-' +
               raw.substring(16, 20) + '-' +
               raw.substring(20, 32)
    }

    def purchaseOrderUuid = normalizeGuid(input.sourceOrderId)
    def responseUuid      = normalizeGuid(input.responseId)
    def deliveryUuid      = normalizeGuid(input.deliveryId)
    def portalOrderUuid   = normalizeGuid(input.portalOrderId)

    def rapPayload = [
        ResponseUUID          : responseUuid,
        OrderRevision         : input.sourceRevision as Integer,
        DeliveryUUID          : deliveryUuid,
        PortalOrderUUID       : portalOrderUuid,
        Supplier              : input.supplierCode.toString(),
        ResponseVersion       : input.responseVersion as Integer,
        SupplierResponse      : input.decision.toString(),
        EstimatedDeliveryDate : input.estimatedDeliveryDate ?: null,
        Reason                : input.reason ?: '',
        RespondedAt           : input.respondedAt
    ]

    message.setProperty(
        'PIH_PurchaseOrderUUID',
        purchaseOrderUuid
    )

    message.setProperty(
        'PIH_RAPActionPath',
        "/PurchaseOrders(${purchaseOrderUuid})/" +
        "com.sap.gateway.srvd_a2x.zjp_api_supplierresponse.v0001.applySupplierResponse"
    )

    message.setProperty(
        'PIH_RAPActionBody',
        JsonOutput.toJson(rapPayload)
    )

    message.setBody(
        JsonOutput.toJson(rapPayload)
    )

    return message
}
