import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    def rawSetCookie = message.getProperty('PIH_SapSetCookie')

    if (rawSetCookie == null) {
        throw new IllegalStateException(
            'SAP Set-Cookie header was not captured.'
        )
    }

    /*
     * Cloud Integration may expose Set-Cookie as a String, Collection,
     * array, or another object whose String representation contains
     * multiple cookies. Normalize everything to one text value first.
     */
    def cookieSources = []

    if (rawSetCookie instanceof Collection) {
        rawSetCookie.each { value ->
            if (value != null) {
                cookieSources << value.toString()
            }
        }
    } else if (rawSetCookie.getClass().isArray()) {
        rawSetCookie.each { value ->
            if (value != null) {
                cookieSources << value.toString()
            }
        }
    } else {
        cookieSources << rawSetCookie.toString()
    }

    def combined = cookieSources.join('; ')

    if (combined.trim().isEmpty()) {
        throw new IllegalStateException(
            'SAP Set-Cookie header was captured but is empty.'
        )
    }

    /*
     * Extract only the cookies that must be sent back to SAP.
     * Do not send Set-Cookie attributes such as Path or HttpOnly.
     */
    def cookies = []
    def matcher = combined =~ /(?i)(sap-usercontext|SAP_SESSIONID_[A-Za-z0-9_]+)=([^;,\]\s]+)/

    matcher.each { match ->
        cookies << "${match[1]}=${match[2]}"
    }

    cookies = cookies.unique()

    if (cookies.isEmpty()) {
        throw new IllegalStateException(
            'SAP session cookies could not be extracted from Set-Cookie.'
        )
    }

    def cookieHeader = cookies.join('; ')

    message.setProperty('PIH_SapCookie', cookieHeader)
    message.setHeader('Cookie', cookieHeader)

    return message
}
