import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    def rawSetCookie = message.getProperty('PIH_SapSetCookie')

    if (rawSetCookie == null || rawSetCookie.toString().trim().isEmpty()) {
        throw new IllegalStateException(
            'SAP Set-Cookie header was not captured.'
        )
    }

    def cookieParts = rawSetCookie
        .toString()
        .split(';')
        .collect { it.trim() }
        .findAll { part ->
            def lower = part.toLowerCase()

            lower.startsWith('sap-usercontext=') ||
            lower.startsWith('sap_sessionid_')
        }

    if (cookieParts.isEmpty()) {
        throw new IllegalStateException(
            'SAP session cookie was not found in Set-Cookie.'
        )
    }

    def cookieHeader = cookieParts.join('; ')

    message.setHeader('Cookie', cookieHeader)

    return message
}
