import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

Message processData(Message message) {
    if (message.getProperty('PihFailureStage') != 'CSRF_FETCH') {
        def caught = message.getProperty('CamelExceptionCaught')
        if (caught instanceof Throwable) {
            throw caught
        }
        throw new IllegalStateException('Failure after CSRF success must remain ambiguous to the caller.')
    }

    def correlationId = message.getProperty('PIH_CorrelationId') ?: ''
    message.setHeader('CamelHttpResponseCode', 503)
    message.setHeader('Content-Type', 'application/json')
    message.setBody(JsonOutput.toJson([
        error: [
            code: 'UPSTREAM_CSRF_UNAVAILABLE',
            message: 'The SAP CSRF token could not be fetched.',
            correlationId: correlationId,
            retryable: true
        ]
    ]))
    return message
}